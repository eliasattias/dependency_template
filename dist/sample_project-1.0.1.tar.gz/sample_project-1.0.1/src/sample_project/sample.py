import logging
import os
logger = logging.getLogger(os.getenv('LOG_ENV'))

hello = 'Hello HAL, I\'m a sample python program'
print(hello)
logger.debug(hello)