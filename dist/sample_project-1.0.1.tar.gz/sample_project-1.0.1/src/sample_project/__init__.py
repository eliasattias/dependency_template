# Place any items that need to be globally initialized here

import logging
import logging.config
import yaml
import dotenv as env

env.load_dotenv()

def setup_logging():
    with open("log_config.yaml",  "r") as f:
        yaml_config = yaml.safe_load(f.read())
        logging.config.dictConfig(yaml_config)
    return yaml_config

setup_logging()