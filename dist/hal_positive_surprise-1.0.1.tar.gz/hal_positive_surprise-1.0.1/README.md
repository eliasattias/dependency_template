# Holland America Positive Surpsie Offers Engine

Positive Surprise project aims to develop a predictive model that recommends best-matched gifts and positive surprises to guests. The goal is to enhance personalization and onboard user experience by leveraging advanced algorithms for gift recommendations

## Installation

Clone Repository

```bash
git clone https://halprdgit01.hq.halw.com:8443/

pip install git+https://halprdgit01.hq.halw.com:8443/scm/gc/hal_positive_surprise.git (Recommend to virtual environment)
```

## Contributing

For any questions, please contact Matthew Perry (MaPerry@HollandAmerica.com) and/or Elias Attias (EAttias@HollandAmerica.com)

## License

[HAL](https://www.hollandamerica.com/en/us)