''' A utility class for managing hal positive surprise queries '''

def positive_surprise_execution():
    ''' Daily process that runs and qualifies guests for positive surprises '''
    return f"""
                BEGIN;;
                -- *****************************************************************************************************
                -- Positive Surprise Execution Snowflake
                -- Daily process that runs and qualifies guests for positive surprises.
                -- OBR team
                -- Version 1.0
                -- Written by Mitch McManaman
                -- Last Update: 2/7/2024
                -- *****************************************************************************************************
                -- *****************************************************************************************************
                -- ****************************  Module 1 - Initial Table  *********************************************
                -- ***************************************************************************************************** 
                -- Currently dropping and creating a new table for the tables in the query so I can check what they are doing and add columns if needed --
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2 AS
                SELECT * FROM (
                -- Initial table to add all the inputs into the query -- 
                --******************************************************************************************************
                ----- Next three sub queries are determining the day that positive surprise will be delivered for spa ---
                with PS_DELIVERY_DAY1 as 
                (SELECT DISTINCT
                    b.VOYAGE_CODE as VOYAGE,
                    a.POLAR_VOYAGE_CODE as VOYAGE_PHYSICAL,
                    b.SHIP_NAME,
                    a.BRAND_CODE_1_CHARACTER as COMPANY_CODE,
                    a.PORT_DATE as PORT_DATE,
                    b.VOYAGE_SAIL_DATE as SAIL_DATE,
                    b.VOYAGE_RETURN_DATE - b.VOYAGE_SAIL_DATE   as SEA_DAYS ,
                    ROUND((b.VOYAGE_RETURN_DATE - b.VOYAGE_SAIL_DATE)/2.5) + b.VOYAGE_SAIL_DATE as LAST_DROP,
                    a.PORT_DATE - b.VOYAGE_SAIL_DATE as DAY_OF_CRUISE, -- What day of cruise this will be delivered , day 0 is turnaround, day 1 is first full day--
                ----------------------  
                -- Making a binary flag for when a ship is in port. Y = ship in port, N = ship not in port-- 
                    CASE 
                    WHEN a.PORT_CODE IN ('XXX' , '270','IDL','CRE','271','272','466') THEN 'N' -- Sea days and scenic cruising days --
                    WHEN a.PORT_CATEGORY_FLAG_CODE = 'T' THEN 'Y' -- T stands for Ship Turnaround -- 
                    WHEN a.PORT_CATEGORY_FLAG_CODE = 'S' THEN 'Y' -- S stands for ship is in port -- 
                    WHEN a.PORT_CATEGORY_FLAG_CODE = 'O' THEN 'Y' -- O stands for overnight --
                    WHEN a.PORT_CATEGORY_FLAG_CODE = 'B' THEN 'Y' -- also has something to do with overnight --
                    WHEN a.PORT_CATEGORY_FLAG_CODE IS NULL THEN 'N' -- null when nothing is happening --
                    END as IN_PORT
                --------------------
                FROM
                    EDW_DB_PRD1.EDW_OWNER.VOYAGE_ITINERARY_FACT_V a
                    JOIN EDW_DB_PRD2.EDW_OWNER.VOYAGE_DIM_V b ON a.POLAR_VOYAGE_CODE = left(b.VOYAGE_CODE,4) AND a.BRAND_SHORT_NAME = b.BRAND_SHORT_NAME
                WHERE
                    b.BRAND_SHORT_NAME IN ('HAL')
                    AND a.BRAND_CODE_1_CHARACTER IN ( 'H' )
                    AND b.VOYAGE_STATUS_CODE = 'A' -- only active voyages --
                    AND b.SHIP_CODE != 'LP' -- removing LANDAM --
                    AND CURRENT_DATE() BETWEEN b.VOYAGE_SAIL_DATE - 5 AND b.VOYAGE_RETURN_DATE + 5
                ),
                -- This querry is making a counter for Sea Days --
                PS_DELIVERY_DAY2 AS (
                SELECT 
                    VOYAGE, 
                    COMPANY_CODE,
                    DAY_OF_CRUISE,
                    IN_PORT,
                    PORT_DATE,
                    SEA_DAYS,
                    ROW_NUMBER() OVER (PARTITION BY VOYAGE ORDER BY DAY_OF_CRUISE) AS SEA_DAY_COUNTER
                FROM PS_DELIVERY_DAY1
                WHERE IN_PORT = 'N'
                ),
                PS_DELIVERY_DAY3 as(
                SELECT DISTINCT
                    a.VOYAGE,
                    a.VOYAGE_PHYSICAL,
                    a.SHIP_NAME,
                    a.COMPANY_CODE,
                    a.SAIL_DATE,
                    a.SAIL_DATE + a.SEA_DAYS as RETURN_DATE,
                    a.SEA_DAYS,
                    a.LAST_DROP,
                ---------------------------
                -- Uncomment these variables if you want to see what the query is doing and check its working --
                --  a.PORT_DATE, 
                --a.IN_PORT, 
                -- b.SEA_DAY_COUNTER, 
                --------------------------
                -----------------------------
                --Below is the logic to select what day the cruise will receive their positive surprises --
                -- Less than 10 sea days - after first set of Sea days (will be delivered between days 2-4 of the cruise --
                --	More than 10 sea days then SEA_DAYS / 2.5 --
                ------------------------------
                CASE 
                    WHEN a.COMPANY_CODE = 'H' AND a.SEA_DAYS < 10 AND a.DAY_OF_CRUISE = 3 AND a.IN_PORT = 'N' AND b.SEA_DAY_COUNTER >=1  THEN (a.PORT_DATE) -- HOLLAND -- deliver to a guest if the 4th day of cruise is a port day --
                    WHEN a.COMPANY_CODE = 'H' AND a.SEA_DAYS < 10 AND a.DAY_OF_CRUISE = 2 AND a.IN_PORT = 'N' AND b.SEA_DAY_COUNTER >=1  THEN (a.PORT_DATE) -- deliver to a guest if the 3rd day of cruise is a port day --
                    WHEN a.COMPANY_CODE = 'H' AND a.SEA_DAYS < 10 AND a.DAY_OF_CRUISE = 1 AND a.IN_PORT = 'N' AND b.SEA_DAY_COUNTER >=1  THEN (a.PORT_DATE) -- deliver to a guest if the 2nd day of cruise is a port day --
                    ELSE a.LAST_DROP -- this is used for cruises 10 days and over and anything that does not meet the above criteria. Last_DROP = SEA_DAYS/2.5 --- 
                    end as SPA_DELIVERY_DATE
                ------------------------------
                FROM 
                    PS_DELIVERY_DAY1 a
                    LEFT JOIN PS_DELIVERY_DAY2 b ON b.VOYAGE=a.VOYAGE  AND a.COMPANY_CODE = b.COMPANY_CODE AND a.PORT_DATE = b.PORT_DATE
                ),
                D_DAY as(
                SELECT DISTINCT
                    VOYAGE,
                    VOYAGE_PHYSICAL,
                    SHIP_NAME,
                    COMPANY_CODE,
                    SAIL_DATE,
                    SAIL_DATE + SEA_DAYS as RETURN_DATE,
                    LAST_DROP,
                    SEA_DAYS,
                    NVL(MIN(SPA_DELIVERY_DATE),LAST_DROP) as SPA_DELIVERY_DATE
                FROM PS_DELIVERY_DAY3
                GROUP BY 
                    VOYAGE,
                    VOYAGE_PHYSICAL,
                    SHIP_NAME,
                    COMPANY_CODE,
                    SAIL_DATE,
                    SAIL_DATE + SEA_DAYS,
                    LAST_DROP,
                    SEA_DAYS
                ),
                -- ******************************************************************************************************************
                ----------------------------------------------------------------------------
                -- Below query is seeing if the guests are celebrating an anniversary or not
                celly as (
                SELECT DISTINCT
                    a.SSG_VOYAGE as VOYAGE,
                    a.SSG_BOOKING_NUMBER as BKNG_NBR,
                    b.VOYAGE_SAIL_DATE,
                    b.VOYAGE_RETURN_DATE,
                    SUM(CASE WHEN a.SSG_ITEM_NUMBER IN ('1000', '1005') THEN 1 ELSE 0 END) AS IF_ANNIVERSARY,
                    SUM(CASE WHEN a.SSG_ITEM_NUMBER IN ('1002', '1006') THEN 1 ELSE 0 END) AS IF_HONEYMOON
                
                FROM 
                    EDW_DB_PRD1.NXG_DWH_OWNER.BKNG_PSNGR_GIFT_V a
                    JOIN EDW_DB_PRD2.EDW_OWNER.VOYAGE_DIM_V b on a.SSG_VOYAGE = b.VOYAGE_CODE
                WHERE
                a.SSG_ITEM_NUMBER IN ('1000', '1005', '1002', '1006')
                AND CURRENT_DATE BETWEEN DATEADD(day, -5, VOYAGE_SAIL_DATE) AND DATEADD(day, +5, VOYAGE_RETURN_DATE)
                GROUP BY 
                    a.SSG_VOYAGE ,
                    a.SSG_BOOKING_NUMBER ,
                    b.VOYAGE_SAIL_DATE,
                    b.VOYAGE_RETURN_DATE
                ),
                --------------------------------------------------------------------------------------
                ---------- Query checking if any guests have pre purchased spa package ---------------
                --------------------------------------------------------------------------------------
                prespa as (
                SELECT DISTINCT 
                    a.VOYAGE_ID as VOYAGE,
                    a.BOOKING_NUMBER,
                    a.PASSENGER_NUMBER,
                    a.BOOKING_NUMBER||0||a.PASSENGER_NUMBER as BKNG_ID,
                    a.SERVICE_NAME,
                    a.SERVICE_DATE,
                    a.TOTAL_SERVICE_REVENUE
                FROM 
                    CRM_DB_PRD1.HA_CRM_ANALYTICS.HA_PREPAID_SPA_V a
                    JOIN EDW_DB_PRD2.EDW_OWNER.VOYAGE_DIM_V b on a.VOYAGE_ID = b.VOYAGE_CODE
                WHERE 
                    CURRENT_DATE BETWEEN DATEADD(day, -5, b.VOYAGE_SAIL_DATE) AND DATEADD(day, +5, b.VOYAGE_RETURN_DATE)
                    AND a.SERVICE_STATUS = 'C'
                ),
                -----------------------------------------------------------------------------------
                ----------------- FMS Data --------------------------------------------------------
                -----------------------------------------------------------------------------------
                FMS as (SELECT DISTINCT
                    SUBSTR(ACC_CONS_ID,9,5) as VOYAGE,
                    a.ACC_RESERV_ID as BKNG_NBR ,
                    left(ACC_CONS_ID , 8) as BKNG_ID,
                    A.ACC_STATUS,
                    CASE A.ACC_STATUS 
                        WHEN 'RR' THEN 'Reservation' 
                        WHEN 'RX' THEN 'Cancelled'
                        WHEN 'RE' THEN 'Embark Today'
                        WHEN 'RN' THEN 'No Show'
                        WHEN 'CC' THEN 'Checked In'
                        WHEN 'CL' THEN 'Leaving Today'
                        WHEN 'DD' THEN 'Disembarked'
                        WHEN '00' THEN 'Error'
                    ELSE 'Unknown'
                    END GUEST_STATUS_DESC,             
                    b.SHP_NAME as SHIP_NAME,
                    a.ACC_EMB_E as SAIL_DATE,
                    a.ACC_DIS_E as RETURN_DATE,
                    a.ACC_CAB_NO as CABIN,
                    a.ACC_FSTN as FIRST_NAME,
                    a.ACC_NAME as LAST_NAME,
                    a.ACC_ACC_REF as FIDELIO_NUMBER
                FROM 
                    "EDW_DB_PRD2"."STG_FMS"."ACC_CURR_V" a,
                    "EDW_DB_PRD2"."STG_FMS"."SHP_CURR_V" b
                WHERE 
                    CURRENT_DATE() BETWEEN to_date(ACC_EMB_E)-5  AND to_date(ACC_DIS_E)+5
                    AND A.ACC_TAG = 'P'
                    AND a.ACC_SHP_ID = b.SHP_ID
                    AND a.ACC_CONS_ID is not null 
                    AND b.SHP_COMPANY = 'Holland America Line'
                    AND right(a.ACC_CONS_ID, 4 ) != '0' 
                    AND a.ACC_RESERV_ID is not null 
                AND a.ACC_CAB_NO != '00000'
                AND try_to_numeric(ACC_CAB_NO)
                -- AND a.ACC_STATUS NOT IN ('RX', 'RN')
                ),
                -----------------------------------------------------------------------------
                -------------- Barclays Flag -------------------------------------------------
                -- Also has a lot of CRM Data if looking for more data -----------------------
                BARCLAYS as (
                SELECT DISTINCT 
                    customer_id as LOYALTY_ID, 
                    BARCLAYS. BARCLAY_FLAG 
                FROM 
                    CRM_DB_PRD1.HA_CRM_ANALYTICS.HA_CONTACT_V Barclays
                WHERE 
                    BARCLAYS.BARCLAY_FLAG = 'Y'
                ),
                ------------------------------------------------------------------------------
                -------------- Past Retail Spend -----------------------------------------
                FINE_JEWLERY_BEFORE AS (
                    SELECT
                        B.VOYAGE_CODE,
                        B.GUEST_LOYALTY_ID as LOYALTY_ID,
                        (CASE
                            WHEN D.FOLIO_TRANSACTION_TYPE_CODE IN ('70501', '70310', '70308', '70301', '70303', '70305', '70306', '70307', '70340', '70390', '70433', '70427')
                            THEN 1
                            ELSE 0
                        END) AS FINE_JEWELRY_BEFORE,
                        CASE 
                        WHEN SUM(F.FOLIO_CHARGE_AMOUNT_USD)>250 THEN 1 ELSE 0 end as RETAIL_250_BEFORE
                    
                    FROM
                        "EDW_DB_PRD2"."EDW_OWNER"."ONBOARD_FOLIO_CHARGES_FACT_V" F
                        INNER JOIN "EDW_DB_PRD2"."EDW_OWNER"."ONBOARD_FOLIO_DEPARTMENT_DIM_V" D ON F.ONBOARD_FOLIO_DEPARTMENT_KEY = D.ONBOARD_FOLIO_DEPARTMENT_KEY
                        INNER JOIN "EDW_DB_PRD2"."EDW_OWNER"."BOOKING_GUEST_DIM_V" B ON F.BOOKING_GUEST_KEY = B.BOOKING_GUEST_KEY
                    WHERE
                        D.FOLIO_DEPARTMENT_NAME IN ('Retail')
                        AND D.FOLIO_CHARGE_CATEGORY = 'Revenue'
                        AND D.BRAND_SHORT_NAME IN ('HAL')
                        AND B.GUEST_LOYALTY_ID IS NOT NULL
                        AND B.GUEST_LOYALTY_ID NOT IN ('222222222A', '222222222B')
                    GROUP BY 
                        B.VOYAGE_CODE,
                        B.GUEST_LOYALTY_ID,
                        D.FOLIO_TRANSACTION_TYPE_CODE
                ),
                RETAIL_BEFORE as (
                SELECT DISTINCT
                    LOYALTY_ID,
                    SUM(FINE_JEWELRY_BEFORE) as FINE_JEWELRY_BEFORE,
                    SUM(RETAIL_250_BEFORE) as RETAIL_250_BEFORE
                FROM 
                    FINE_JEWLERY_BEFORE
                GROUP BY 
                    LOYALTY_ID
                ),
                -------------------------------------------------------------------------------
                -------------------------- Iniitial Table -------------------------------------
                -------------------------------------------------------------------------------
                initial_table as (SELECT DISTINCT 
                -- Basic Person Data --
                    TIGER.BOOKING_NO as BKNG_NBR,
                    0||TIGER.PAX_NUM as PAX_NUM,
                    TIGER.BOOKING_NO||0||TIGER.PAX_NUM as BKNG_ID,
                    TIGER.CCN as LOYALTY_ID,
                    FMS.FIDELIO_NUMBER,
                    SPLIT_PART(FMS.FIRST_NAME, ' ', 1) AS FIRST_NAME,
                    FMS.LAST_NAME,
                -- Basic Booking Data --
                    CASE 
                        WHEN TIGER.BRAND = 'HA' THEN 'H'
                        ELSE 'ERROR' 
                    end as COMPANY_CODE,
                    TIGER.VOYAGE_ID as VOYAGE,
                    TIGER.SHIP_CODE,
                    UPPER(SUBSTR(TIGER.SHIP_NAME, 4)) as SHIP_NAME,  -- removing the ms before the ship name--
                    TIGER.SAIL_DATE,
                    TIGER.RETURN_DATE,
                    TIGER.SAIL_DURATION as SEA_DAYS, 
                    FMS.CABIN,
                    TIGER.CABIN_META,
                    TIGER.CABIN_SUB_META,
                    TIGER.TRADE,
                    TIGER.SUB_TRADE,
                    TIGER.EMBARKATION_PORT,
                    TIGER.DEBARKATION_PORT,
                    TIGER.BIRTH_DATE,
                    TIGER.AGE_WHEN_CRUISED as AGE,
                    ---- Birthday of month during cruise check -----
                    IFF(MONTH(Tiger.BIRTH_DATE) BETWEEN MONTH(Tiger.SAIL_DATE) AND MONTH(Tiger.RETURN_DATE)  AND  DAY(Tiger.BIRTH_DATE) BETWEEN DAY(Tiger.SAIL_DATE) AND DAY(Tiger.RETURN_DATE),
                        1,0) AS BD_OF_MONTH,
                    ----- -------
                    ------------------ DETERMINING IF GUESTS ARE CELEBRATING ANYTHING ------------------
                    CASE WHEN celly.IF_ANNIVERSARY > 0 then 1 end as IF_ANNIVERSARY,
                    CASE WHEN celly.IF_HONEYMOON > 0 then 1 end as IF_HONEYMOON,
                    CASE 
                    WHEN celly.IF_HONEYMOON > 0 THEN 'HONEYMOON'
                    WHEN celly.IF_ANNIVERSARY > 0 THEN 'ANNIVERSARY'
                    WHEN MONTH(Tiger.BIRTH_DATE) BETWEEN MONTH(Tiger.SAIL_DATE) AND MONTH(Tiger.RETURN_DATE)  AND  DAY(Tiger.BIRTH_DATE) BETWEEN DAY(Tiger.SAIL_DATE) AND DAY(Tiger.RETURN_DATE) THEN 'BDAY'
                    else 'SURPRISE' end as CARD_TEMPLATE,
                    -------------------------------------------------------------------------------------
                    TIGER.GENDER,
                    TIGER.COUNTRY,
                    TIGER.CURRENT_LOYALTY_LEVEL,
                    -------------------CASE to make Loyalty Level numbers -----------------------------
                    CASE 
                        CURRENT_LOYALTY_LEVEL
                        WHEN 'One Star' THEN 1
                        WHEN 'Two Star' THEN 2
                        WHEN 'Three Star' THEN 3 
                        WHEN 'Four Star' THEN 4
                        WHEN 'Five Star' THEN 5
                        WHEN 'President''s Club' THEN 6   -- Assuming 6 represents President's Club
                        ELSE 0 
                    END AS number_loyalty_LEVEL,
                    ----------------------------------------------------------------------------------
                    NVL(TIGER.NBR_CRUISES_WITHIN_PAST_5_YRS,0) as NBR_CRUISES_WITHIN_PAST_5_YRS,
                    NVL(TIGER.NBR_CRUISES_INPAST,0) as NBR_CRUISES_INPAST,
                    TIGER.NBR_FUTURE_CRUISE_TRVLED_BOOKED as FUTURE_CRUISE_COUNT,
                    TIGER.PASSENGER_COUNT,
                    ----- KIDS IN CABIN CASE STATEMENT --------
                    CASE
                        WHEN MIN_AGE_IN_BKNG < 18 THEN 1 
                        ELSE 0 
                    END as KIDS_IN_CABIN_FLAG,
                    -------------------------------------------
                    ----- MAKING THE BELOW STATEMENTS BINARY --------------------
                    CASE WHEN TIGER.CASINO_FLAG = 'Y' THEN 1 ELSE 0 END AS CASINO_FLAG,
                    CASE WHEN TIGER.INCLUSIVE_FLAG = 'Y' THEN 1 ELSE 0 END AS HIA_FLAG,
                    CASE WHEN TIGER.TICKET_BAR_PKG_FLAG = 'Y' THEN 1 ELSE 0 END AS BAR_PKG_FLAG,
                    CASE WHEN TIGER.LAST_CASINO_FLAG = 'Y' THEN 1 ELSE 0 END AS LAST_CASINO_FLAG,
                    CASE WHEN TIGER.LAST_INCLUSIVE_FLAG = 'Y' THEN 1 ELSE 0 END AS LAST_HIA_FLAG,
                    CASE WHEN TIGER.LAST_TICKET_BAR_PKG_FLAG = 'Y' THEN 1 ELSE 0 END AS LAST_BAR_PKG_FLAG,
                    CASE WHEN BARCLAYS.BARCLAY_FLAG = 'Y' THEN 1 ELSE 0 END AS BARCLAY_FLAG,
                    ------------------------------------
                    TIGER.DRINKS_SOLD_PER_DIEM,	
                    TIGER.DRINKS_COST	,
                    TIGER.DRINKS_COST_PER_DIEM,
                    TIGER.PST_CASINO_BKNG_CNT,	
                    TIGER.PST_INCLUSIVE_CNT,	
                    TIGER.PST_TICKET_BAR_PKG_CNT,	
                    TIGER.VOYAGE_CAPACITY,	
                    TIGER.PCD	,
                    TIGER.B_P_GROSS	as NTR,
                    TIGER.B_P_GROSS / TIGER.SAIL_DURATION as  NTR_PER_DIEM,
                    PERCENT_RANK() OVER (PARTITION BY TIGER.VOYAGE_ID ORDER BY TIGER.B_P_GROSS) AS NTR_PERCENTILE,
                    TIGER.B_P_FCC_DISCOUNT,	
                    TIGER.FCC_PER_DIEM,	
                    ----------- SUM Current Onboard Spend ----------------------
                    TIGER.SHOREX_REV + TIGER.FB_REV + tiger.PHOTO_REV + tiger.RETAIL_REV + tiger.SPA_REV + 
                    tiger.MISC_REV + tiger.GAMING_REV + tiger.MEDICAL_REV + tiger.OBC_REV + tiger.GRATUITY_REV 
                    AS CURRENT_CRUISE_OBR,
                    -------------------------------------------------------------
                    TIGER.SHOREX_REV,
                    TIGER.FB_REV,	
                    tiger.PHOTO_REV,
                    tiger.RETAIL_REV,
                    RETAIL.FINE_JEWELRY_BEFORE,
                    RETAIL.RETAIL_250_BEFORE,
                    tiger.SPA_REV,
                    ------------- Pre Spa Flag ------------------
                    Case 
                        when prespa.TOTAL_SERVICE_REVENUE is not null then 1 else 0
                    end as PRE_SPA_FLAG,
                    ------------------------------------------------------
                    tiger.MISC_REV,
                    tiger.GAMING_REV,
                    tiger.MEDICAL_REV,
                    tiger.OBC_REV,
                    tiger.GRATUITY_REV,
                    tiger.SHOREX_PER_DIEM,
                    tiger.FB_PER_DIEM,
                    tiger.PHOTO_PER_DIEM,
                    tiger.RETAIL_PER_DIEM,
                    tiger.SPA_PER_DIEM,
                    tiger.INTERNET_PER_DIEM,
                    tiger.MISC_PER_DIEM,
                    tiger.GAMING_PER_DIEM,
                    tiger.MEDICAL_PER_DIEM,
                    tiger.OBC_PER_DIEM,
                    tiger.GRATUITY_PER_DIEM,
                    tiger.PCT_VOY_WITH_SHX_SPEND,
                    tiger.PCT_VOY_WITH_FB_SPEND,
                    tiger.PCT_VOY_WITH_PHOTO_SPEND,
                    tiger.PCT_VOY_WITH_RETAIL_SPEND,
                    tiger.PCT_VOY_WITH_SPA_SPEND,
                    tiger.PCT_VOY_WITH_INTERNET_SPEND,
                    tiger.PCT_VOY_WITH_MISC_SPEND,
                    tiger.PCT_VOY_WITH_GAMING_SPEND,
                    tiger.PCT_VOY_WITH_MEDICAL_SPEND,
                    tiger.PCT_VOY_WITH_OBC_SPEND,
                    tiger.PCT_VOY_WITH_GRATUITY_SPEND,
                    tiger.AVG_PAST_GROSS_PER_DIEM,
                    tiger.FUTURE_VOYAGE_CNT,
                    tiger.PAST_GROSS,
                    tiger.AVG_PST_GROSS_PERCENTILE,
                    -------- Total Average Spend Calculation --------
                        tiger.AVG_SHOREX_PER_DIEM +  tiger.AVG_FB_PER_DIEM + tiger.AVG_PHOTO_PER_DIEM +  tiger.AVG_RETAIL_PER_DIEM +  tiger.AVG_SPA_PER_DIEM + tiger.AVG_INTERNET_PER_DIEM +
                        tiger.AVG_MISC_PER_DIEM + tiger.AVG_GAMING_PER_DIEM + tiger.AVG_MEDICAL_PER_DIEM + tiger.AVG_OBC_PER_DIEM + tiger.AVG_GRATUITY_PER_DIEM 
                        AS AVG_DAILY_OBR_SPEND,
                    --------------------------------------------------
                    -------- HOBS Calculation -- eventually want to replace with actual list --------
                    CASE
                        WHEN tiger.AVG_SHOREX_PER_DIEM +  tiger.AVG_FB_PER_DIEM + tiger.AVG_PHOTO_PER_DIEM +  tiger.AVG_RETAIL_PER_DIEM +  tiger.AVG_SPA_PER_DIEM + tiger.AVG_INTERNET_PER_DIEM +
                        tiger.AVG_MISC_PER_DIEM + tiger.AVG_GAMING_PER_DIEM + tiger.AVG_MEDICAL_PER_DIEM + tiger.AVG_OBC_PER_DIEM + tiger.AVG_GRATUITY_PER_DIEM > 100 
                        THEN 1 ELSE 0 
                    end AS HOBS,
                    --------------------------------------------------
                    tiger.AVG_SHOREX_PER_DIEM,
                    tiger.AVG_FB_PER_DIEM,
                    tiger.AVG_PHOTO_PER_DIEM,
                    tiger.AVG_RETAIL_PER_DIEM,
                    tiger.AVG_SPA_PER_DIEM,
                    tiger.AVG_INTERNET_PER_DIEM,
                    tiger.AVG_MISC_PER_DIEM,
                    tiger.AVG_GAMING_PER_DIEM,
                    tiger.AVG_MEDICAL_PER_DIEM,
                    tiger.AVG_OBC_PER_DIEM,
                    tiger.AVG_GRATUITY_PER_DIEM,
                    tiger.DAY_DIFF_LAST_SHOREX_SPEND,
                    tiger.DAY_DIFF_LAST_FB_SPEND,
                    tiger.DAY_DIFF_LAST_PHOTO_SPEND,
                    tiger.DAY_DIFF_LAST_RETAIL_SPEND,
                    tiger.DAY_DIFF_LAST_SPA_SPEND,
                    tiger.DAY_DIFF_LAST_INTERNET_SPEND,
                    tiger.DAY_DIFF_LAST_MISC_SPEND,
                    tiger.DAY_DIFF_LAST_GAMING_SPEND,
                    tiger.DAY_DIFF_LAST_MEDICAL_SPEND,
                    tiger.DAY_DIFF_LAST_OBC_SPEND,
                    tiger.DAY_DIFF_LAST_GRATUITY_SPEND,
                -------- checking if guest spent at spa last time they cruised ----------      
                    CASE
                        WHEN
                        LEAST(
                            NVL(tiger.DAY_DIFF_LAST_SHOREX_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_FB_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_PHOTO_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_RETAIL_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_SPA_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_INTERNET_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_MISC_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_GAMING_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_MEDICAL_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_OBC_SPEND, 99999),
                            NVL(tiger.DAY_DIFF_LAST_GRATUITY_SPEND, 99999)
                            ) = tiger.DAY_DIFF_LAST_SPA_SPEND THEN 1 ELSE 0 
                    END AS LAST_CRUISE_SPA_SPEND,
                -------- ---------------------------------------------------------------- 
                    FMS.GUEST_STATUS_DESC,
                    FMS.ACC_STATUS,
                    d_day.SPA_DELIVERY_DATE,
                    BKNG.PROMO_ARRAY,
                    CURRENT_DATE as REFRESH_DT
                FROM 
                    EDW_DB_PRD2.EDW_REPORTING.HIGH_SPENDERS_V TIGER
                    LEFT JOIN FMS ON  FMS.BKNG_ID = TIGER.BOOKING_NO||0||TIGER.PAX_NUM
                    -- LEFT JOIN WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.HK_SECTIONS HK ON UPPER(SUBSTR(TIGER.SHIP_NAME, 4))= HK.SHIP AND HK.CABIN = FMS.CABIN
                    LEFT JOIN prespa ON TIGER.BOOKING_NO||0||TIGER.PAX_NUM = prespa.BKNG_ID
                    LEFT JOIN d_day ON TIGER.VOYAGE_ID = d_day.VOYAGE
                    LEFT JOIN celly ON tiger.booking_no = celly.BKNG_NBR
                    LEFT JOIN  BARCLAYS on BARCLAYS.LOYALTY_ID = TIGER.CCN
                    LEFT JOIN RETAIL_BEFORE RETAIL ON TIGER.CCN = RETAIL.LOYALTY_ID
                    LEFT JOIN "EDW_DB_PRD2"."EDW_OWNER"."BOOKING_GUEST_DIM_V" BKNG ON TIGER.BOOKING_NO = BKNG.BOOKING_NUMBER
                WHERE 
                    CURRENT_DATE IN (d_day.SPA_DELIVERY_DATE ,  tiger.SAIL_DATE)
                    AND VOYAGE_CANCEL_INDICATOR = 0
                    AND FMS.ACC_STATUS NOT IN ('RX', 'RN')
                    AND TIGER.SAIL_dATE > '2024-04-17'
                    AND TIGER.AGE_WHEN_CRUISED >= 18
                    AND TIGER.SAIL_DURATION > 4
                    AND BKNG.BRAND_SHORT_NAME = 'HAL'
                    AND BKNG.PASSENGER_ID = '01'
                    AND (BKNG.PROMO_ARRAY NOT LIKE '%YB%' OR BKNG.PROMO_ARRAY NOT LIKE '%YI%' OR BKNG.PROMO_ARRAY NOT LIKE '%FN%' 
                    OR BKNG.PROMO_ARRAY NOT LIKE '%FH%' OR BKNG.PROMO_ARRAY NOT LIKE '%FS%')
                )
                    SELECT * FROM initial_table
                );;
                -------------------------------------------------------------------------------------------------------
                SELECT DISTINCT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2;;
                -------------------------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 2 - Cabin Initial Table  ***************************************
                -- ***************************************************************************************************** 
                -- Taking all the above data and putting it at the cabin level -- will give positive surprise at the cabin level
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2 AS
                SELECT DISTINCT
                    BKNG_NBR,
                    MAX(TO_NUMBER(CABIN)) as CABIN, -- taking the MAX because in a handful of cases the same BKNG number has different room numbers which causes problems later
                    COMPANY_CODE,
                    VOYAGE,
                    SHIP_CODE,
                    SHIP_NAME,
                    SAIL_DATE,
                    RETURN_DATE,
                    SEA_DAYS,
                    CABIN_META,
                    CABIN_SUB_META,
                -- HK_SECTION,
                    TRADE,
                    SUB_TRADE,
                    EMBARKATION_PORT,
                    DEBARKATION_PORT,
                    PASSENGER_COUNT,
                    LISTAGG(FIRST_NAME, ' , ') WITHIN GROUP (ORDER BY FIRST_NAME) as FIRST_NAMES, -- combining all guests first names
                    SUM(NTR) as CABIN_NTR,
                    CASE WHEN SUM(HIA_FLAG) > 0 then 1 else 0 end as CABIN_HIA_FLAG, -- does anyone in cabin have HIA?
                    CASE WHEN SUM(CASINO_FLAG) > 0 then 1 else 0 end as CABIN_CASINO_FLAG, -- is anyone in cabin a Casino guest?
                    CASE WHEN SUM(BAR_PKG_FLAG) > 0 then 1 else 0 end as CABIN_BAR_PKG_FLAG, -- does anyone in cabin have a bar package?
                    CASE WHEN SUM(KIDS_IN_CABIN_FLAG) > 0 then 1 else 0 end as KIDS_IN_CABIN_FLAG, -- any kids in cabin?
                    CASE WHEN SUM(BARCLAY_FLAG) > 0 then 1 else 0 end as CABIN_BARCLAY_FLAG, -- anyone have the Holland Barclays card in cabin?
                    CASE WHEN SUM(NBR_CRUISES_INPAST) = 0 then 1 else 0 end as ROOKIE_CABIN_FLAG, -- is the entire cabin rookies?
                    CASE WHEN SUM(HOBS) > 0 then 1 else 0 end as CABIN_HOBS_FLAG, -- anyone in cabin HOBS?
                    CASE WHEN SUM(FINE_JEWELRY_BEFORE) > 0 then 1 else 0 end as CABIN_FJ_BEFORE_FLAG, -- anyone spend on Fine Jewelry before in cabin
                    CASE WHEN SUM(RETAIL_250_BEFORE) > 0 then 1 else 0 end as CABIN_RETAIL_250_BEFORE, -- has the cabin spent $250 in retail before
                    CASE WHEN SUM(IF_ANNIVERSARY) > 0 then 1 else 0 end as CABIN_ANNIVERSARY,
                    CASE WHEN SUM(IF_HONEYMOON) > 0 then 1 else 0 end as CABIN_HONEYMOON,
                    CASE WHEN SUM(BD_OF_MONTH) > 0 then 1 else 0 end as CABIN_BDAY,
                    CASE 
                        WHEN SUM(IF_ANNIVERSARY) > 0 then 'ANNIVERSARY'
                        WHEN SUM(IF_HONEYMOON) > 0 then 'HONEYMOON' 
                    else 'SURPRISE' end as CARD_TEMPLATE,
                ----------case to decide what country the guests are from ------------------------------------------------
                    CASE 
                    WHEN COUNT(*) = 1 THEN MAX(COUNTRY)  -- Only one person in the cabin, show their country
                    WHEN COUNT(DISTINCT COUNTRY) > 1 THEN 'MIXED'  -- Multiple people with different countries
                    ELSE MAX(COUNTRY)
                    END as CABIN_COUNTRY, -- Multiple people, but all from the same country end as CABIN_COUNTRY,
                    -------------------------------------------------------------------------------------------------------
                    MAX(number_loyalty_LEVEL) as CABIN_MAX_LOYALTY_LEVEL,
                    AVG(NTR_PERCENTILE) as CABIN_NTR_PERCENTILE,
                    SUM(CURRENT_CRUISE_OBR) as CABIN_CURRENT_CRUISE_OBR,
                    SUM(SHOREX_REV) as CABIN_SHOREX_REV,
                    SUM(FB_REV) as CABIN_FB_REV,
                    SUM(PHOTO_REV) as CABIN_PHOTO_REV,
                    SUM(RETAIL_REV) as CABIN_RETAIL_REV,
                    SUM(SPA_REV) as CABIN_SPA_REV,
                    SUM(MISC_REV) as CABIN_MISC_REV,
                    SUM(GAMING_REV) as CABIN_GAMING_REV,
                    SUM(MEDICAL_REV) as CABIN_MEDICAL_REV,
                    SUM(OBC_REV) as CABIN_OBC_REV,
                    SUM(GRATUITY_REV) as CABIN_GRATUITY_REV,
                    SUM(AVG_DAILY_OBR_SPEND) as CABIN_AVG_DAILY_OBR_SPEND,
                    SUM(AVG_SHOREX_PER_DIEM) as CABIN_AVG_SHOREX_PER_DIEM,
                    SUM(AVG_FB_PER_DIEM) as CABIN_AVG_FB_PER_DIEM,
                    SUM(AVG_PHOTO_PER_DIEM) as CABIN_AVG_PHOTO_PER_DIEM,
                    SUM(AVG_SPA_PER_DIEM) as CABIN_AVG_SPA_PER_DIEM,
                    SUM(AVG_RETAIL_PER_DIEM) as CABIN_AVG_RETAIL_PER_DIEM,
                    SUM(AVG_INTERNET_PER_DIEM) as CABIN_AVG_INTERNET_PER_DIEM,
                    SUM(AVG_MISC_PER_DIEM) as CABIN_AVG_MISC_PER_DIEM,
                    SUM(AVG_GAMING_PER_DIEM) as CABIN_AVG_GAMING_PER_DIEM,
                    SUM(AVG_MEDICAL_PER_DIEM) as CABIN_AVG_MEDICAL_PER_DIEM,
                    SUM(AVG_OBC_PER_DIEM) as CABIN_AVG_OBC_PER_DIEM,
                    SUM(AVG_GRATUITY_PER_DIEM) as CABIN_AVG_GRATUITY_PER_DIEM
                FROM
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2
                GROUP BY 
                    BKNG_NBR,
                    COMPANY_CODE,
                    VOYAGE,
                    SHIP_CODE,
                    SHIP_NAME,
                    SAIL_DATE,
                    RETURN_DATE,
                    SEA_DAYS,
                    CABIN_META,
                    CABIN_SUB_META,
                -- HK_SECTION,
                    TRADE,
                    SUB_TRADE,
                    EMBARKATION_PORT,
                    DEBARKATION_PORT,
                    PASSENGER_COUNT
                ;;
                ----------------------------------------------------------------------------------------
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2;;
                ----------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 3 -Spa Qualification  ******************************************
                -- ***************************************************************************************************** 
                -- Selecting all guests that are eligible for Spa Positive Surprise ------------------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_CABINS_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_CABINS_V2 AS
                SELECT DISTINCT
                    COMPANY_CODE,
                    VOYAGE,
                    BKNG_NBR,
                    BKNG_ID,
                    ------------------------ Spa Qualification ----------------------------------------------------------------------------------------
                    CASE 
                    WHEN SPA_REV > 0 then 0 -- if any spa spend, no offer will be given
                    WHEN AGE < 18 then 0 -- guest must be 18 or older to recieve
                    WHEN PRE_SPA_FLAG = 1 then 0 -- no precruise spa spend --
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 0 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 1
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 2 
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 1 then 3
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 4
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND > 0 AND HOBS = 1 then 5
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND > 0 AND HOBS = 0 then 0 -- turned off would be group 6
                    WHEN BD_OF_MONTH = 1 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 1 then 0 -- turned off would be group 7
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 0 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 8
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 9
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND = 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 1 then 10
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 0 then 11
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND = 0 AND HOBS = 1 then 0 -- turned off would be group 12
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND > 0 AND HOBS = 0 then 0 -- turned off would be group 13
                    WHEN BD_OF_MONTH = 0 AND NBR_CRUISES_INPAST > 1 AND PCT_VOY_WITH_SPA_SPEND > 0 AND LAST_CRUISE_SPA_SPEND > 0 AND HOBS = 1 then 0 -- turned off would be group 14
                    END as "GROUP",
                    --------------------------------------------------------------------------------------------------------------------------------------
                    -------------------------- Random Variable -- more used just to check ----------------------------------------------------------------
                -- PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY BKNG_NBR) AS random_variable,
                    --------------------------------------------------------------------------------------------------------------------------------------
                ---------------------------- Random Variable for test/control determination ------------------------------------------------------------ 
                --- Using the below statement to randomize the variables, if you have same BKNG_NBR you will have same test or control group ----------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY BKNG_NBR)  <=.85 THEN 'TEST'
                    ELSE 'CONTROL'
                    END as TCGROUPS,
                ---------------------------------------------------------------------------------------------------------------------------------------  
                --------------------------- Using same random variable to add in value of the card given -----------------------------------------------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY BKNG_NBR)  <=.85 THEN 50
                    ELSE 0
                    END as AMOUNT,
                ---------------------------------------------------------------------------------------------------------------------------------------     
                    'SPA101' as OFFER_CODE
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2
                WHERE
                SPA_DELIVERY_DATE = CURRENT_DATE
                AND "GROUP" != 0
                ;;
                ---------------------------------------------------------------------------------------------
                SELECT DISTINCT  * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_CABINS_V2;;
                ----------------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 4a - Effy Qualification  ****************************************
                -- ***************************************************************************************************** 
                -- Selecting all guests that are eligible for EFFY Positive Surprise ------------------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_EFFY_OFFER_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_EFFY_OFFER_V2 AS
                SELECT DISTINCT
                    COMPANY_CODE,
                    VOYAGE,
                    BKNG_NBR,
                    ------------------------ EFFY Qualification ----------------------------------------------------------------------------------------
                    CASE 
                    WHEN CABIN_ANNIVERSARY > 0 OR CABIN_HONEYMOON > 0 or CABIN_BDAY > 0 then 17 -- adding in all celebrations
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '0' then 1
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '1' then 2
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '0' then 3
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '1' then 4
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '0' then 5
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '1' then 6
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '0' then 7
                    WHEN CABIN_META = 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '1' then 0 -- 0 indicates not eligible
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '0' then 0 -- 0 indicates not eligible
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '1' then 10
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '0' then 11
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '0' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '1' then 0 -- 0 indicates not eligible
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '0' then 13
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '0' AND CABIN_HOBS_FLAG = '1' then 0 -- 0 indicates not eligible
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '0' then 0 -- 0 indicates not eligible
                    WHEN CABIN_META != 'S' AND CABIN_RETAIL_250_BEFORE = '1' AND CABIN_FJ_BEFORE_FLAG = '1' AND CABIN_HOBS_FLAG = '1' then 0 -- 0 indicates not eligible
                    else 0 end as "GROUP" ,
                    --------------------------------------------------------------------------------------------------------------------------------------
                    -------------------------- Random Variable -- more used just to check ----------------------------------------------------------------
                -- PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY BKNG_NBR) AS random_variable,
                    --------------------------------------------------------------------------------------------------------------------------------------
                ---------------------------- Random Variable for test/control determination ------------------------------------------------------------ 
                --- Using the below statement to randomize the variables, if you have same BKNG_NBR you will have same test or control group ----------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR))  <=.85 THEN 'TEST'
                    ELSE 'CONTROL'
                    END as TCGROUPS,
                ---------------------------------------------------------------------------------------------------------------------------------------  
                --------------------------- Using same random variable to add in value of the card given -----------------------------------------------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR))   <=.85 THEN 250
                    ELSE 0
                    END as AMOUNT,
                ---------------------------------------------------------------------------------------------------------------------------------------     
                'EFFY101' as OFFER_CODE
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2 
                WHERE 
                    SAIL_DATE = CURRENT_DATE
                    AND "GROUP" != 0 
                ;;
                ----------------------------------------------------------------------------------------
                SELECT DISTINCT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_EFFY_OFFER_V2
                ORDER BY VOYAGE;;
                ----------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 4b - Photo Qualification  ***************************************
                -- ***************************************************************************************************** 
                -- Selecting all guests that are eligible for Photot Positive Surprise ------------------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PHOTO_OFFER_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PHOTO_OFFER_V2 AS
                SELECT DISTINCT
                    COMPANY_CODE,
                    VOYAGE,
                    BKNG_NBR,
                    ------------ Photo Qualification -----------------------------------------------------------------------------------------  
                    CASE   
                        WHEN CABIN_ANNIVERSARY = 1 THEN 1 -- segment 1 is given to people with anniversary and honeymoon --
                        WHEN CABIN_HONEYMOON = 1 THEN 1  
                        WHEN KIDS_IN_CABIN_FLAG > 0 THEN 2 -- segment 2 is given to cabins with kids -- 
                        WHEN CABIN_AVG_PHOTO_PER_DIEM > 20 THEN 3  -- segment 3 is given to people who have spent more than $20 a day in spa in past -- 
                        WHEN CABIN_HOBS_FLAG =  1 then 4  -- segment 4 is HOBS guests -- 
                        WHEN CABIN_NTR_PERCENTILE > .75 THEN 5  -- segment 5 is given to people in top 25% of NTR -- 
                        WHEN CABIN_HIA_FLAG = 1 THEN 6 -- segment 6 is for HIA cabins
                    ELSE 0 END as "GROUP" ,
                ---------------------------- Random Variable for test/control determination ------------------------------------------------------------ 
                --- Using the below statement to randomize the variables, if you have same BKNG_NBR you will have same test or control group ----------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR , FIRST_NAMES))  <=.95 THEN 'TEST'
                    ELSE 'CONTROL'
                    END as TCGROUPS,
                ---------------------------------------------------------------------------------------------------------------------------------------  
                --------------------------- Using same random variable to add in value of the card given -----------------------------------------------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR , FIRST_NAMES))  <=.95 THEN 100
                    ELSE 0
                    END as AMOUNT,
                ---------------------------------------------------------------------------------------------------------------------------------------     
                    'PHOTO101' as OFFER_CODE
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2
                WHERE
                SAIL_DATE = CURRENT_DATE
                AND "GROUP" != 0
                --
                ;;   
                ------------------------------------------------------------------------------------
                SELECT DISTINCT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PHOTO_OFFER_V2;;
                ------------------------------------------------------------------------------------
                ----------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 4c - Credit Card Qualification  ********************************
                -- *****************************************************************************************************    
                -- Selecting all guests that are eligible for Credit Card positive Surprise ----------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CC_OFFER_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CC_OFFER_V2 AS
                SELECT DISTINCT
                    COMPANY_CODE,
                    VOYAGE,
                    BKNG_NBR,
                    ------------------------ CC Qualification ----------------------------------------------------------------------------------------
                    CASE 
                    WHEN CABIN_MAX_LOYALTY_LEVEL > 1 AND CABIN_COUNTRY = 'US' AND CABIN_META = 'S' then 1
                    ELSE 0 end as "GROUP",
                    --------------------------------------------------------------------------------------------------------------------------------------
                ---------------------------- Random Variable for test/control determination ------------------------------------------------------------ 
                --- Using the below statement to randomize the variables, if you have same BKNG_NBR you will have same test or control group ----------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR))  <=.5 THEN 'TEST'
                    ELSE 'CONTROL'
                    END as TCGROUPS,
                ---------------------------------------------------------------------------------------------------------------------------------------  
                --------------------------- Using same random variable to add in value of the card given -----------------------------------------------
                    CASE 
                    WHEN PERCENT_RANK() OVER (PARTITION BY  VOYAGE ORDER BY HASH(BKNG_NBR))   <=.5 THEN 200
                    ELSE 0
                    END as AMOUNT,
                ---------------------------------------------------------------------------------------------------------------------------------------     
                    'CC101' as OFFER_CODE
                FROM
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2
                WHERE 
                    SAIL_DATE = CURRENT_DATE
                    AND "GROUP" != 0 
                ;;
                ---------------------------------------------------------------------------------
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CC_OFFER_V2
                ORDER BY VOYAGE;;
                ---------------------------------------------------------------------------------
                ----------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 5 - Combining Cabin Offers  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_OFFERS_V2;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_OFFERS_V2 AS 
                SELECT * FROM (
                WITH combine_offers as (
                    SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_EFFY_OFFER_V2
                    UNION
                    SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PHOTO_OFFER_V2
                    UNION
                    SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CC_OFFER_V2
                ),
                ----------------------------------------------------------------------------------------------
                priority as (
                SELECT DISTINCT * ,
                ------------ case statement to randomize what two offers guests are recievin. Can change this to prioritize certain offers --------
                CASE OFFER_CODE
                    WHEN 'EFFY101' then random()
                    When 'PHOTO101' then random()
                    When 'CC101' then random()
                END as priority
                --------------------------------------------------------------------------------------------------------------------------------
                FROM 
                    COMBINE_OFFERS
                ),
                ----------------------------------------------------------------------------------------------
                ranked_offers as (
                SELECT DISTINCT
                    COMPANY_CODE,
                    VOYAGE,
                    BKNG_NBR,
                    "GROUP",
                    TCGROUPS,
                    AMOUNT,
                    OFFER_CODE,
                    CASE 
                    WHEN TCGROUPS = 'TEST' THEN  ROW_NUMBER() OVER (PARTITION BY BKNG_NBR ORDER BY PRIORITY) 
                    WHEN TCGROUPS = 'CONTROL' THEN 100
                    END AS Ranked_Offer
                FROM
                    priority
                )
                -------------------------------------------------------------------------------
                SELECT distinct * FROM ranked_offers
                ORDER BY VOYAGE, BKNG_NBR, RANKED_OFFER)
                ;;
                ---------------------------------------------------------------------------------
                SELECT DISTINCT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_OFFERS_V2
                ORDER BY VOYAGE, BKNG_NBR;;
                ---------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 6 - Data Warehouse  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                INSERT into workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY
                with cabin_Data_Storage as(
                SELECT DISTINCT
                    a.VOYAGE,
                    b.SHIP_NAME,
                    b.SAIL_DATE,
                    CURRENT_DATE as DELIVERY_DATE,
                    a.BKNG_NBR,
                    null as BKNG_ID,
                    a.OFFER_CODE,
                    CASE
                    WHEN OFFER_CODE = 'CC101' then 'Cc'
                    WHEN OFFER_CODE = 'EFFY101' then 'Effy'
                    WHEN OFFER_CODE = 'PHOTO101' then 'Photo'
                    end as DEPARTMENT,   
                    a."GROUP",
                    a.AMOUNT,
                    CASE 
                    WHEN a.RANKED_OFFER <= 2 AND a.TCGROUPS = 'TEST' then 'TEST'
                    ELSE 'CONTROL'
                    END as TCGROUPS,
                    b.CARD_TEMPLATE,
                    'PRINT' as CHANNEL,
                    'CABIN' as OFFER_TYPE,
                    CURRENT_TIMESTAMP() as UPLOAD_TIME
                    
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_OFFERS_V2 a
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2 b on a.BKNG_NBR = b.BKNG_NBR),
                ------------------------------------------------------------------------------------
                SPA_DATA_STORAGE as(
                SELECT DISTINCT
                    a.VOYAGE,
                    b.SHIP_NAME,
                    b.SAIL_DATE,
                    CURRENT_DATE as DELIVERY_DATE,
                    a.BKNG_NBR,
                    a.BKNG_ID,
                    a.OFFER_CODE,
                    'Spa' as DEPARTMENT,
                    a."GROUP",
                    a.AMOUNT,
                    a.TCGROUPS,
                    b.CARD_TEMPLATE,
                    'PRINT' as CHANNEL,
                    'INDIVIDUAL' as OFFER_TYPE,
                    CURRENT_TIMESTAMP() as UPLOAD_TIME
                    
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_CABINS_V2 a
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2 b on a.BKNG_ID = b.BKNG_ID)  ,
                --------------------------------------------------------------------------------------
                FINAL_UPLOAD_LIST as (
                    SELECT * FROM SPA_DATA_STORAGE
                    UNION
                    SELECT * FROM CABIN_DATA_STORAGE)
                SELECT * FROM FINAL_UPLOAD_LIST;;
                --------------------------------------------------------------------------------------------
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY;;

                ---------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 6s - Onboard List generation  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                --INSERT into workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY
                INSERT into workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_ONBOARD_GUEST_LISTS 
                SELECT DISTINCT
                    a.VOYAGE,
                    a.SHIP_NAME,
                    a.SAIL_DATE,
                    a.DELIVERY_DATE,
                    a.BKNG_NBR,
                    a.BKNG_ID,
                    a.OFFER_CODE,
                    a.DEPARTMENT,
                    a.AMOUNT,
                    a.CARD_TEMPLATE,
                    CASE WHEN a.BKNG_ID is null then b.CABIN else c.CABIN end as CABIN,
                    CASE WHEN a.BKNG_ID is null then b.FIRST_NAMES else c.FIRST_NAME || ' ' || c.LAST_NAME end as NAME_ON_CARD,
                    CURRENT_TIMESTAMP() AS UPLOAD_TIME
                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY a 
                    LEFT JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2 b ON a.BKNG_NBR = b.BKNG_NBR
                    LEFT JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2 c ON a.BKNG_ID = c.BKNG_ID
                WHERE 
                    TO_DATE(a.UPLOAD_TIME) = CURRENT_DATE
                    AND a.TCGROUPS = 'TEST';;
                --------------------------------------------------------------------------------------
                SELECT *  FROM  workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_ONBOARD_GUEST_LISTS;;
                --------------------------------------------------------------------------------------------
                --------------------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 7a - Cabin Print File  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_PRINT_FILE;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_PRINT_FILE AS 
                with CABIN_PRINT_FILE as (
                SELECT DISTINCT
                a.VOYAGE,
                b.SHIP_NAME,
                to_char(b.SAIL_DATE,'MM/DD/YYYY' ) as SAIL_DATE,
                b.BKNG_NBR,
                INITCAP(b.FIRST_NAMES) as first_names,
                b.CABIN,
                a.OFFER_CODE,
                a.AMOUNT,
                a.CARD_TEMPLATE,
                HK.HK_SECTION,
                CASE 
                    WHEN C.OFFER_CODE = 'CC101' then c.OFFER_GIFT_CARD
                    ELSE '$' || a.AMOUNT || ' ' || c.OFFER_GIFT_CARD
                END as OFFER_GIFT_CARD,
                c.OFFER,
                C.TC,
                CASE WHEN a.OFFER_CODE = 'CC101' then null else to_char(b.RETURN_DATE,'MM/DD/YYYY' ) end as EXPIRATION_DATE,
                CASE 
                    WHEN a.OFFER_CODE = 'SPA101' THEN d.SPA_DECK
                    WHEN a.OFFER_CODE = 'EFFY101' THEN d.EFFY_DECK
                    WHEN a.OFFER_CODE = 'SHOREX101' THEN d.SHOREX_DECK 
                    WHEN a.OFFER_CODE = 'PHOTO101' THEN d.PHOTO_DECK
                    WHEN a.OFFER_CODE = 'SHOPS101' THEN d.SHOPS_DECK
                    WHEN a.OFFER_CODE = 'ART101' THEN d.ART_DECK
                    WHEN a.OFFER_CODE = 'DINE101' then d.CANALETTO_DECK
                end as LOCATION,  
                ROW_NUMBER() OVER (PARTITION BY a.VOYAGE , b.BKNG_NBR ORDER BY AMOUNT) as OFFER_NBR

                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY a
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_CABIN_TABLE_V2 b on a.BKNG_NBR = b.BKNG_NBR
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_OFFER_COLLATERAL c on a.OFFER_CODE = c.OFFER_CODE
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.SHIP_MAPPING d ON b.SHIP_NAME = d.ship_NAME
                    LEFT JOIN WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.HK_SECTIONS HK ON b.SHIP_NAME = HK.SHIP AND HK.CABIN = b.CABIN

                WHERE
                DATE_TRUNC(day,a.UPLOAD_TIME) = CURRENT_DATE 
                AND a.TCGROUPS = 'TEST'
                AND a.OFFER_TYPE = 'CABIN'),

                CABIN_PRINT_FILE2 as (
                SELECT DISTINCT
                    a.VOYAGE,
                    a.SHIP_NAME,
                    a.SAIL_DATE,
                    a.BKNG_NBR,
                    a.FIRST_NAMES as NAME,
                    a.HK_SECTION,
                    'Cabin: ' ||a.CABIN as CABIN,
                    a.OFFER_CODE AS OFFER_CODE1,
                    a.AMOUNT AS AMOUNT1,
                    a.CARD_TEMPLATE AS CARD_TEMPLATE1,
                    'HK Section: ' || a.HK_SECTION AS HOUSEKEEP_SECTION,
                    a.OFFER_GIFT_CARD AS OFFER1_GIFT_CARD,
                    a.OFFER AS OFFER1,
                    a.TC AS TC1,
                    a.EXPIRATION_DATE AS EXPIRATION_DATE,
                    'Redeem at deck ' ||a.LOCATION as LOCATION1,
                    b.first_NAMEs as NAME2,
                    'Cabin: ' ||b.CABIN as CABIN2,
                    b.SHIP_NAME as SHIP_NAME2,
                    b.SAIL_DATE as SAIL_DATE2,
                    b.OFFER_CODE AS OFFER_CODE2,
                    b.AMOUNT AS AMOUNT2,
                    b.CARD_TEMPLATE AS CARD_TEMPLATE2,
                    'HK Section: ' || b.HK_SECTION AS HOUSEKEEP_SECTION2,
                    b.OFFER_GIFT_CARD AS OFFER2_GIFT_CARD,
                    b.OFFER AS OFFER2,
                    b.TC AS TC2,
                    b.EXPIRATION_DATE AS EXPIRATION_DATE2,
                    'Redeem at deck ' ||b.LOCATION as LOCATION2,
                        CASE 
                        WHEN a.CARD_TEMPLATE = 'SURPRISE' THEN ''
                        WHEN a.CARD_TEMPLATE = 'BDAY' THEN 'HAPPY BIRTHDAY'
                        WHEN a.CARD_TEMPLATE = 'ANNIVERSARY' THEN 'HAPPY ANNIVERSARY'
                        WHEN a.CARD_TEMPLATE = 'HONEYMOON' THEN 'HAPPY HONEYMOON'
                        ELSE '' 
                    END as HEADER
                FROM
                    CABIN_PRINT_FILE a
                LEFT JOIN
                    CABIN_PRINT_FILE b ON a.BKNG_NBR = b.BKNG_NBR AND b.OFFER_NBR = 2
                WHERE
                    a.OFFER_NBR = 1)
                SELECT * FROM CABIN_PRINT_FILE2;;
                ----------------------------------------------------------------  
                SELECT * FROM   workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_PRINT_FILE
                ORDER BY HK_SECTION;;
                --------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 7a - Spa Print File  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_PRINT_FILE;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_PRINT_FILE AS
                SELECT DISTINCT
                a.VOYAGE,
                b.SHIP_NAME,
                to_char(b.SAIL_DATE,'MM/DD/YYYY' ) as SAIL_DATE,
                b.BKNG_ID,
                INITCAP(b.FIRST_NAME)||' '|| INITCAP(b.LAST_NAME) as name,
                'Cabin: ' || b.CABIN as CABIN,
                a.OFFER_CODE,
                a.AMOUNT,
                a.CARD_TEMPLATE,
                HK.HK_SECTION,
                'HK Section: ' || HK.HK_SECTION AS HOUSEKEEP_SECTION,
                CASE 
                    WHEN C.OFFER_CODE = 'CC101' then c.OFFER_GIFT_CARD
                    ELSE '$' || a.AMOUNT || ' ' || c.OFFER_GIFT_CARD
                END as OFFER_GIFT_CARD,
                c.OFFER,
                C."TC" as TC,
                to_char(b.RETURN_DATE,'MM/DD/YYYY' ) as  EXPIRATION_DATE,
                    'Redeem at deck ' ||d.SPA_DECK as LOCATION

                FROM 
                    workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY a
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2 b on a.BKNG_ID = b.BKNG_ID
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_OFFER_COLLATERAL c on a.OFFER_CODE = c.OFFER_CODE
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.SHIP_MAPPING d ON b.SHIP_NAME = d.ship_NAME
                    LEFT JOIN WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.HK_SECTIONS HK ON b.SHIP_NAME = HK.SHIP AND HK.CABIN = b.CABIN
                WHERE
                DATE_TRUNC(day,a.UPLOAD_TIME) = CURRENT_DATE 
                AND a.TCGROUPS = 'TEST'
                AND a.OFFER_TYPE = 'INDIVIDUAL'

                ;;
                -------------------------------------------------------
                SELECT DISTINCT* FROM  workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_PRINT_FILE
                ORDER BY HK_SECTION;;
                -----------------------------------------------------------------------------
                --------------------------------------------------------------------------------
                -- *****************************************************************************************************
                -- ****************************  Module 8 - Push Notification File  ********************************
                -- *****************************************************************************************************    
                -- XXXXXXXXXXXXXXX ----------------------------
                DROP TABLE IF EXISTS workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PUSH_NOT_FILE;;
                CREATE TABLE workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PUSH_NOT_FILE AS 
                with spa_not as (
                SELECT DISTINCT
                    b.SHIP_NAME,
                ------------------------ case statement to change Ship codes to match ITs ship codes
                    CASE 
                        WHEN b.SHIP_CODE = 'RN' THEN 'RT'
                        WHEN b.SHIP_CODE = 'UU' THEN 'ZU'
                        WHEN b.SHIP_CODE = 'ED' THEN 'EU'
                        WHEN b.SHIP_CODE = 'AA' THEN 'ZA'
                        ELSE to_CHAR(b.SHIP_CODE) 
                    end as SHIP_CODE,
                ------------------------------------------
                    a.VOYAGE,
                    TO_CHAR(b.SAIL_DATE, 'YYYY-MM-DD') as SAIL_DATE,
                    TO_CHAR(b.RETURN_DATE, 'YYYY-MM-DD') as RETURN_DATE,
                    b.FIRST_NAME,
                    b.LAST_NAME,
                    b.BKNG_NBR,
                    b.BKNG_ID,
                    SUBSTR(b.BKNG_ID, -2) as PARTY_ID,
                    b.FIDELIO_NUMBER,
                    b.LOYALTY_ID,
                    b.CABIN,
                ------------------ changing offer_code to department
                    SUBSTRING(a.OFFER_CODE, 1, LENGTH(a.OFFER_CODE) - 3)  as OFFER_DEPT,
                -------------
                    a.OFFER_CODE,
                    '$' || a.AMOUNT || ' GIFT CARD'  as offer,
                ----------- top line of card
                    CASE 
                    WHEN b.IF_ANNIVERSARY = 1 then 'Happy Anniversary!'
                    WHEN b.IF_HONEYMOON = 1 then 'Happy Honeymoon!'
                    WHEN b.BD_OF_MONTH = 1 then 'Happy Birthday!'
                    ELSE 'Surprise!' 
                    end as offerTitle,
                ------------------------- second line of card
                --    CASE 
                --        WHEN OFFER_CODE = '101' THEN 'Enjoy this gift card '
                --        WHEN OFFER_CODE = '102' THEN 'Enjoy this gift card '
                --        ELSE 'ERROR' 
                --    END as OFFER_MESSAGE,
                    'Enjoy this gift card ' as OFFER_MESSAGE,
                ---------------- card template - does not go on card
                    b.CARD_TEMPLATE,
                ------------------
                    a.AMOUNT,
                ------------------ What day the cards are going to be delivered 
                    TO_CHAR(CURRENT_DATE, 'YYYY-MM-DD') as DELIVERY_DATE,
                    --DATEADD(DAY, 2, CURRENT_DATE()) as DELIVERY_DATE,
                ------------------
                    '1700' as DELIVERY_TIME, -- what time the cards will be delivered shipboard time 1700 = 5pm
                    TO_CHAR(b.RETURN_DATE, 'YYYY-MM-DD') as EXPIRATION_DATE, -- need to update
                -------------------- Terms and Conditions    
                    c."TC" as terms,
                --------------------- places where the ship
                CASE WHEN a.OFFER_CODE = 'SPA101' THEN d.SPA_DECK
                    WHEN a.OFFER_CODE = 'EFFY101' THEN d.EFFY_DECK
                    WHEN a.OFFER_CODE = 'SHOREX101' THEN d.SHOREX_DECK 
                    WHEN a.OFFER_CODE = 'PHOTO101' THEN d.PHOTO_DECK
                    WHEN a.OFFER_CODE = 'SHOPS101' THEN d.SHOPS_DECK
                    WHEN a.OFFER_CODE = 'ART101' THEN d.ART_DECK
                    WHEN a.OFFER_CODE = 'DINE101' then d.CANALETTO_DECK
                end as LOCATION,  
                ---------------------
                FROM  
                        workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY a
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_INITIAL_TABLE_V2 b on a.BKNG_ID = b.BKNG_ID
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_OFFER_COLLATERAL c on a.OFFER_CODE = c.OFFER_CODE
                    JOIN workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.SHIP_MAPPING d ON b.SHIP_NAME = d.ship_NAME

                WHERE 
                    DATE_TRUNC(day,a.UPLOAD_TIME) = CURRENT_DATE 
                    AND a.TCGROUPS = 'TEST'
                    AND a.OFFER_TYPE = 'INDIVIDUAL')

                SELECT * FROM spa_not;;
                -------------------------------------------------------------------------------
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PUSH_NOT_FILE;;
                -------------------------------------------------------------------------------
                COMMIT;;                    
            """


def upcoming_voyages():
    ''' Get the upcoming voyages '''
    return f"""
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY
                WHERE DATE_TRUNC('day', UPLOAD_TIME) = CURRENT_DATE
                AND TCGROUPS = 'TEST';
            """


def voyage_department_data(ship_name, sail_date, department):
    ''' Get a list of qualified guests for a specific ship, sail date, and department '''
    return f"""
                SELECT * FROM WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_ONBOARD_GUEST_LISTS
                WHERE SHIP_NAME = '{ship_name}' AND SAIL_DATE = '{sail_date.strftime('%m/%d/%Y')}' 
                AND DEPARTMENT = '{department.title()}' AND DELIVERY_DATE = CURRENT_DATE
            """

def voyage_spa_print_data(ship_name, sail_date):
    ''' Get a list of qualified spa guests for a specific ship in preparation for the mail merge format '''
    return f"""
                SELECT * FROM WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_SPA_PRINT_FILE
                WHERE SHIP_NAME = '{ship_name}' AND SAIL_DATE = '{sail_date.strftime('%m/%d/%Y')}' 
                ORDER BY HK_SECTION, CABIN
            """

def voyage_cabin_print_data(ship_name, sail_date):
    ''' Get a list of qualified cabin guests for a specific ship in preparation for the mail merge format '''
    return f"""
                SELECT * FROM WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_CABIN_PRINT_FILE
                WHERE SHIP_NAME = '{ship_name}' AND SAIL_DATE = '{sail_date.strftime('%m/%d/%Y')}' 
                ORDER BY HK_SECTION, CABIN
            """

def voyage_test_history_data(ship_name, sail_date):
    ''' Get a list of qualified guests for a specific ship '''
    return f"""
                SELECT * FROM WORKAREA_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_HISTORY
                WHERE SHIP_NAME = '{ship_name}' AND SAIL_DATE = '{sail_date.strftime('%m/%d/%Y')}' 
                 AND TCGROUPS = 'TEST'
            """

def voyage_push_notifications_data():
    ''' Get a list of qualified guests for a specific ship for the app '''
    return f"""
                SELECT * FROM workarea_DB_PRD1.WORKAREA_STRATEGY_PERF_MGMT.PS_PUSH_NOT_FILE 
            """
